#include "shell.h"
#include "screen.h"
#include "keyboard.h"
#include "memory.h"
#include "scheduler.h"
#include "filesystem.h"

static int str_eq(const char* a, const char* b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void str_copy(char* dst, const char* src, int max) {
    int i = 0;
    while (src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static int parse_int(const char* s) {
    if (!s || !*s) return -1;
    int n = 0;
    while (*s >= '0' && *s <= '9') { n = n * 10 + (*s - '0'); s++; }
    return n;
}

static int split(char* buf, char** argv, int max_args) {
    int argc = 0;
    while (*buf && argc < max_args) {
        while (*buf == ' ') buf++;
        if (!*buf) break;
        argv[argc++] = buf;
        while (*buf && *buf != ' ') buf++;
        if (*buf) { *buf = '\0'; buf++; }
    }
    return argc;
}

/* Get content after "cmd filename " from original unmodified line */
static const char* get_content(const char* line) {
    int words = 0;
    while (*line) {
        /* skip spaces */
        while (*line == ' ') line++;
        if (!*line) break;
        words++;
        /* skip word */
        while (*line && *line != ' ') line++;
        if (words == 2) {
            /* skip spaces after second word */
            while (*line == ' ') line++;
            return *line ? line : (const char*)0;
        }
    }
    return (const char*)0;
}

static void add_proc(const char* name, int burst, int priority) {
    int pid = process_create(name, burst, priority);
    if (pid == -1) {
        screen_print("  ERROR: could not create "); screen_print(name); screen_print("\n");
    } else {
        screen_print("  [+] PID "); screen_print_int(pid);
        screen_print(" "); screen_print(name);
        screen_print(" burst="); screen_print_int(burst);
        screen_print(" pri="); screen_print_int(priority);
        screen_print("\n");
    }
}

void shell_run() {
    char buf[128];
    char orig[128];
    char* argv[8];
    int   argc;

    while (1) {
        screen_print("sleos> ");
        keyboard_readline(buf, 128);

        /* save original before split modifies it */
        str_copy(orig, buf, 128);

        argc = split(buf, argv, 8);
        if (argc == 0) continue;

        if (str_eq(argv[0], "help")) {
            screen_set_color(COLOR_CYAN, COLOR_BLACK);
            screen_print("=== SLeOS Commands ===\n");
            screen_set_color(COLOR_WHITE, COLOR_BLACK);
            screen_print("PROCESS MANAGEMENT:\n");
            screen_print("  addproc <name> <burst> <pri>  add a process\n");
            screen_print("  delproc <pid>                 delete a process\n");
            screen_print("  initproc                      load 8 demo processes\n");
            screen_print("  ps                            list processes\n");
            screen_print("  fcfs                          FCFS scheduling\n");
            screen_print("  rr                            Round Robin scheduling\n");
            screen_print("MEMORY MANAGEMENT:\n");
            screen_print("  memmap                        show frame map\n");
            screen_print("  memalloc <name> <size_kb>     allocate memory\n");
            screen_print("  memfree <id>                  free allocation\n");
            screen_print("FILE SYSTEM:\n");
            screen_print("  ls                            list files\n");
            screen_print("  create <filename>             create a file\n");
            screen_print("  write <filename> <content>    write to file\n");
            screen_print("  read <filename>               read a file\n");
            screen_print("  delete <filename>             delete a file\n");
            screen_print("OTHER:\n");
            screen_print("  clear                         clear screen\n");

        } else if (str_eq(argv[0], "clear")) {
            clear_screen();

        } else if (str_eq(argv[0], "ps")) {
            scheduler_list_processes();

        } else if (str_eq(argv[0], "addproc")) {
            if (argc < 4) {
                screen_print("Usage: addproc <name> <burst> <priority>\n");
            } else {
                char name[16];
                str_copy(name, argv[1], 16);
                int burst    = parse_int(argv[2]);
                int priority = parse_int(argv[3]);
                if (burst <= 0) screen_print("Error: burst must be > 0\n");
                else add_proc(name, burst, priority);
            }

        } else if (str_eq(argv[0], "delproc")) {
            if (argc < 2) {
                screen_print("Usage: delproc <pid>\n");
            } else {
                int pid = parse_int(argv[1]);
                if (pid <= 0) screen_print("Error: invalid PID\n");
                else {
                    process_terminate(pid);
                    screen_print("  [-] PID "); screen_print_int(pid);
                    screen_print(" terminated\n");
                }
            }

        } else if (str_eq(argv[0], "initproc")) {
            screen_print("[INIT] Loading demo processes...\n");
            add_proc("init",     1, 0);
            add_proc("kernel",   3, 0);
            add_proc("shell",    5, 1);
            add_proc("editor",   8, 2);
            add_proc("browser", 12, 2);
            add_proc("fileserv", 6, 1);
            add_proc("netdrv",   4, 1);
            add_proc("clock",    2, 3);
            screen_print("[INIT] Done. Type 'ps' to see them.\n");

        } else if (str_eq(argv[0], "fcfs")) {
            scheduler_run_fcfs();

        } else if (str_eq(argv[0], "rr")) {
            scheduler_run_rr();

        } else if (str_eq(argv[0], "memmap")) {
            screen_set_color(COLOR_YELLOW, COLOR_BLACK);
            screen_print("=== Memory Frame Map ===\n");
            screen_set_color(COLOR_WHITE, COLOR_BLACK);
            memory_show_map();

        } else if (str_eq(argv[0], "memalloc")) {
            if (argc < 3) {
                screen_print("Usage: memalloc <label> <size_kb>\n");
            } else {
                int size = parse_int(argv[2]);
                if (size <= 0) screen_print("Error: size must be > 0\n");
                else {
                    int id = memory_alloc(argv[1], size);
                    if (id == -1) {
                        screen_print("[MEM] Allocation failed\n");
                    } else {
                        screen_print("[MEM] Allocated "); screen_print_int(size);
                        screen_print("KB for '"); screen_print(argv[1]);
                        screen_print("' -> ID "); screen_print_int(id); screen_print("\n");
                        memory_show_map();
                    }
                }
            }

        } else if (str_eq(argv[0], "memfree")) {
            if (argc < 2) {
                screen_print("Usage: memfree <id>\n");
            } else {
                int id = parse_int(argv[1]);
                if (id <= 0) screen_print("Error: invalid ID\n");
                else {
                    int ok = memory_free(id);
                    if (!ok) {
                        screen_print("[MEM] No allocation with ID ");
                        screen_print_int(id); screen_print("\n");
                    } else {
                        screen_print("[MEM] Freed ID "); screen_print_int(id); screen_print("\n");
                        memory_show_map();
                    }
                }
            }

        } else if (str_eq(argv[0], "ls")) {
            screen_set_color(COLOR_YELLOW, COLOR_BLACK);
            screen_print("=== File System ===\n");
            screen_set_color(COLOR_WHITE, COLOR_BLACK);
            fs_list();

        } else if (str_eq(argv[0], "create")) {
            if (argc < 2) {
                screen_print("Usage: create <filename>\n");
            } else {
                if (fs_create(argv[1]))
                    { screen_print("[FS] Created: "); screen_print(argv[1]); screen_print("\n"); }
                else
                    screen_print("[FS] Error: file exists or fs full\n");
            }

        } else if (str_eq(argv[0], "write")) {
            if (argc < 3) {
                screen_print("Usage: write <filename> <content>\n");
                screen_print("  e.g. write notes.txt Hello SLeOS\n");
            } else {
                /* use orig to get content after "write filename " */
                const char* content = get_content(orig);
                if (!content) content = "";
                if (fs_write(argv[1], content)) {
                    screen_print("[FS] Written to: "); screen_print(argv[1]); screen_print("\n");
                } else {
                    screen_print("[FS] Error: could not write\n");
                }
            }

        } else if (str_eq(argv[0], "read")) {
            if (argc < 2) {
                screen_print("Usage: read <filename>\n");
            } else {
                char out[256];
                int len = fs_read(argv[1], out, 256);
                if (len == 0) {
                    screen_print("[FS] File not found or empty: ");
                    screen_print(argv[1]); screen_print("\n");
                } else {
                    screen_set_color(COLOR_CYAN, COLOR_BLACK);
                    screen_print("--- "); screen_print(argv[1]); screen_print(" ---\n");
                    screen_set_color(COLOR_WHITE, COLOR_BLACK);
                    screen_print(out); screen_print("\n---\n");
                }
            }

        } else if (str_eq(argv[0], "delete")) {
            if (argc < 2) {
                screen_print("Usage: delete <filename>\n");
            } else {
                if (fs_delete(argv[1]))
                    { screen_print("[FS] Deleted: "); screen_print(argv[1]); screen_print("\n"); }
                else
                    { screen_print("[FS] Not found: "); screen_print(argv[1]); screen_print("\n"); }
            }

        } else {
            screen_print("Unknown command: "); screen_print(argv[0]);
            screen_print(" (type 'help')\n");
        }
    }
}
