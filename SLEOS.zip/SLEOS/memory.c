#include "memory.h"
#include "screen.h"

#define TOTAL_FRAMES  16
#define FRAME_SIZE_KB  4
#define MAX_ALLOCS    10

static uint8_t frame_table[TOTAL_FRAMES];
static Allocation alloc_table[MAX_ALLOCS];
static int next_alloc_id = 1;

void memory_init() {
    for (int i = 0; i < TOTAL_FRAMES; i++) frame_table[i] = 0;
    for (int i = 0; i < MAX_ALLOCS;   i++) alloc_table[i].active = 0;
    next_alloc_id = 1;
}

static int find_free_frames(int count) {
    int run = 0;
    for (int i = 0; i < TOTAL_FRAMES; i++) {
        if (!frame_table[i]) { if (++run == count) return i - count + 1; }
        else run = 0;
    }
    return -1;
}

int memory_alloc(const char* label, int size_kb) {
    if (size_kb <= 0) return -1;
    int nf = (size_kb + FRAME_SIZE_KB - 1) / FRAME_SIZE_KB;
    int st = find_free_frames(nf);
    if (st == -1) { screen_print("[MEM] ERROR: Not enough frames!\n"); return -1; }
    for (int i = 0; i < MAX_ALLOCS; i++) {
        if (!alloc_table[i].active) {
            alloc_table[i].alloc_id     = next_alloc_id++;
            alloc_table[i].frames_start = st;
            alloc_table[i].num_frames   = nf;
            alloc_table[i].active       = 1;
            int j = 0;
            while (label[j] && j < 15) { alloc_table[i].label[j] = label[j]; j++; }
            alloc_table[i].label[j] = '\0';
            for (int f = st; f < st + nf; f++) frame_table[f] = 1;
            return alloc_table[i].alloc_id;
        }
    }
    return -1;
}

int memory_free(int alloc_id) {
    for (int i = 0; i < MAX_ALLOCS; i++) {
        if (alloc_table[i].active && alloc_table[i].alloc_id == alloc_id) {
            for (int f = alloc_table[i].frames_start;
                 f < alloc_table[i].frames_start + alloc_table[i].num_frames; f++)
                frame_table[f] = 0;
            alloc_table[i].active = 0;
            return 1;
        }
    }
    return 0;
}

int memory_get_free_kb() {
    int f = 0;
    for (int i = 0; i < TOTAL_FRAMES; i++) if (!frame_table[i]) f++;
    return f * FRAME_SIZE_KB;
}

int memory_get_total_kb() { return TOTAL_FRAMES * FRAME_SIZE_KB; }

void memory_show_map() {
    screen_print("[MEM] Frame map: [");
    for (int i = 0; i < TOTAL_FRAMES; i++)
        screen_putchar(frame_table[i] ? '#' : '.');
    screen_print("]\n");
    screen_print("[MEM] Free: ");
    screen_print_int(memory_get_free_kb());
    screen_print("KB / Total: ");
    screen_print_int(memory_get_total_kb());
    screen_print("KB\n");
}
