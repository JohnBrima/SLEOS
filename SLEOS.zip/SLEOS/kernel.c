#include "kernel.h"
#include "screen.h"
#include "scheduler.h"
#include "memory.h"
#include "filesystem.h"
#include "shell.h"

void kernel_main() {
    clear_screen();
    print_banner();

    screen_print("[INIT] Initializing Memory Manager...\n");
    memory_init();
    screen_print("[OK]   Memory Manager ready.\n");

    screen_print("[INIT] Initializing Process Scheduler...\n");
    scheduler_init();
    screen_print("[OK]   Scheduler ready.\n");

    screen_print("[INIT] Initializing File System...\n");
    fs_init();
    screen_print("[OK]   File System ready.\n");

    screen_print("\n");
    screen_print("================================================\n");
    screen_print("  Welcome to Sierra Leone OS (SLeOS) v1.0\n");
    screen_print("  Built by Limkokwing University Students\n");
    screen_print("  Freetown, Sierra Leone\n");
    screen_print("================================================\n");
    screen_print("\nType 'help' to see available commands.\n\n");

    shell_run();

    while (1) {}
}

void print_banner() {
    screen_set_color(COLOR_GREEN, COLOR_BLACK);
    screen_print(" _____ _     ___  ___  ___\n");
    screen_print("|  ___| |   / _ \\/ _ \\/ __|\n");
    screen_print("| |__ | |  | | | | | | \\__ \\\n");
    screen_print("|_____|_|  |_| |_|_| |_|___/\n");
    screen_print("Sierra Leone Operating System\n\n");
    screen_set_color(COLOR_WHITE, COLOR_BLACK);
}
