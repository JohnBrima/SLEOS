#ifndef KERNEL_H
#define KERNEL_H

typedef unsigned char  uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int   uint32_t;
typedef int            int32_t;
typedef char           int8_t;

#define NULL    0
#define TRUE    1
#define FALSE   0

typedef int bool;

#define COLOR_BLACK   0
#define COLOR_BLUE    1
#define COLOR_GREEN   2
#define COLOR_CYAN    3
#define COLOR_RED     4
#define COLOR_MAGENTA 5
#define COLOR_BROWN   6
#define COLOR_WHITE   7
#define COLOR_YELLOW  14

void kernel_main();
void print_banner();

#endif
