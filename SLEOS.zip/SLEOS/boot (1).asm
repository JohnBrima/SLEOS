BITS 16
ORG 0x7c00

start:
    cli
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7c00
    sti

    mov si, msg_boot
    call print_string

    ; Load kernel into 0x1000:0x0000 = physical 0x10000
    mov ah, 0x02        ; BIOS read sectors
    mov al, 50          ; load 50 sectors (25KB, kernel is ~20KB)
    mov ch, 0           ; cylinder 0
    mov cl, 2           ; start from sector 2
    mov dh, 0           ; head 0
    mov dl, 0x80        ; first hard disk
    mov bx, 0x1000
    mov es, bx          ; ES = 0x1000
    xor bx, bx          ; BX = 0x0000, so ES:BX = 0x10000
    int 0x13
    jc disk_error

    ; Switch to protected mode
    cli
    o32 lgdt [gdt_descriptor]
    mov eax, cr0
    or eax, 1
    mov cr0, eax
    jmp CODE_SEG:init_pm

disk_error:
    mov si, msg_disk_err
    call print_string
    hlt

print_string:
    lodsb
    or al, al
    jz .done
    mov ah, 0x0E
    int 0x10
    jmp print_string
.done:
    ret

msg_boot     db 'SLeOS Bootloader starting...', 13, 10, 0
msg_disk_err db 'ERROR: Could not read disk!', 13, 10, 0

gdt_start:
    dq 0x0000000000000000
gdt_code:
    dw 0xffff, 0x0000, 0x9a00, 0x00cf
gdt_data:
    dw 0xffff, 0x0000, 0x9200, 0x00cf
gdt_end:

gdt_descriptor:
    dw gdt_end - gdt_start - 1
    dd gdt_start

CODE_SEG equ gdt_code - gdt_start
DATA_SEG equ gdt_data - gdt_start

BITS 32
init_pm:
    mov ax, DATA_SEG
    mov ds, ax
    mov ss, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ebp, 0x90000
    mov esp, ebp
    call 0x10000
    hlt

times 510-($-$$) db 0
dw 0xaa55
