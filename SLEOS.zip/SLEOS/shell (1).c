#include "shell.h"
#include "screen.h"
#include "keyboard.h"
#include "memory.h"
#include "scheduler.h"
#include "filesystem.h"

static int str_eq(const char* a, const char* b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static void str_copy(char* dst, const char* src, int max) {
    int i = 0;
    while (src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static int parse_int(const char* s) {
    if (!s || !*s) return -1;
    int n = 0;
    while (*s >= '0' && *s <= '9') { n = n * 10 + (*s - '0'); s++; }
    return n;
}

static int split(char* buf, char** argv, int max_args) {
    int argc = 0;
    while (*buf && argc < max_args) {
        while (*buf == ' ') buf++;
        if (!*buf) break;
        argv[argc++] = buf;
        while (*buf && *buf != ' ') buf++;
        if (*buf) { *buf = '\0'; buf++; }
    }
    return argc;
}

static void add_proc(const char* name, int burst, int priority) {
    int pid = process_create(name, burst, priority);
    if (pid == -1) {
        screen_print("  ERROR: could not create ");
        screen_print(name); screen_print("\n");
    } else {
        screen_print("  [+] PID ");
        screen_print_int(pid);
        screen_print(" ");  screen_print(name);
        screen_print(" burst="); screen_print_int(burst);
        screen_print(" pri=");   screen_print_int(priority);
        screen_print("\n");
    }
}

void shell_run() {
    char buf[128];
    char* argv[8];
    int   argc;

    while (1) {
        screen_print("sleos> ");
        keyboard_readline(buf, 128);
        argc = split(buf, argv, 8);
        if (argc == 0) continue;

        /* ── help ── */
        if (str_eq(argv[0], "help")) {
            screen_print("Process commands:\n");
            screen_print("  addproc <name> <burst> <pri>  add a process\n");
            screen_print("  delproc <pid>                 delete a process\n");
            screen_print("  initproc                      load 8 demo processes\n");
            screen_print("  ps                            list all processes\n");
            screen_print("  fcfs                          run FCFS simulation\n");
            screen_print("  rr                            run Round Robin\n");
            screen_print("Other commands:\n");
            screen_print("  memmap  ls  clear\n");

        /* ── clear ── */
        } else if (str_eq(argv[0], "clear")) {
            clear_screen();

        /* ── memmap ── */
        } else if (str_eq(argv[0], "memmap")) {
            memory_show_map();

        /* ── ls ── */
        } else if (str_eq(argv[0], "ls")) {
            fs_list();

        /* ── ps ── */
        } else if (str_eq(argv[0], "ps")) {
            scheduler_list_processes();

        /* ── addproc <name> <burst> <priority> ── */
        } else if (str_eq(argv[0], "addproc")) {
            if (argc < 4) {
                screen_print("Usage: addproc <name> <burst> <priority>\n");
                screen_print("  e.g. addproc MyApp 10 1\n");
            } else {
                char name[16];
                str_copy(name, argv[1], 16);
                int burst    = parse_int(argv[2]);
                int priority = parse_int(argv[3]);
                if (burst <= 0)
                    screen_print("Error: burst must be a positive number\n");
                else
                    add_proc(name, burst, priority);
            }

        /* ── delproc <pid> ── */
        } else if (str_eq(argv[0], "delproc")) {
            if (argc < 2) {
                screen_print("Usage: delproc <pid>\n");
                screen_print("  e.g. delproc 3\n");
                screen_print("  (use 'ps' to see PIDs)\n");
            } else {
                int pid = parse_int(argv[1]);
                if (pid <= 0) {
                    screen_print("Error: invalid PID\n");
                } else {
                    process_terminate(pid);
                    screen_print("  [-] PID ");
                    screen_print_int(pid);
                    screen_print(" terminated\n");
                }
            }

        /* ── initproc ── */
        } else if (str_eq(argv[0], "initproc")) {
            screen_print("[INIT] Loading demo processes...\n");
            add_proc("init",     1,  0);
            add_proc("kernel",   3,  0);
            add_proc("shell",    5,  1);
            add_proc("editor",   8,  2);
            add_proc("browser", 12,  2);
            add_proc("fileserv", 6,  1);
            add_proc("netdrv",   4,  1);
            add_proc("clock",    2,  3);
            screen_print("[INIT] Done. Type 'ps' to see them.\n");

        /* ── fcfs ── */
        } else if (str_eq(argv[0], "fcfs")) {
            scheduler_run_fcfs();

        /* ── rr ── */
        } else if (str_eq(argv[0], "rr")) {
            scheduler_run_rr();

        } else {
            screen_print("Unknown command: ");
            screen_print(argv[0]);
            screen_print(" (type 'help')\n");
        }
    }
}
