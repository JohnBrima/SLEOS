#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "kernel.h"

#define MAX_PROCESSES 10

typedef enum {
    PROC_EMPTY      = 0,
    PROC_READY      = 1,
    PROC_RUNNING    = 2,
    PROC_TERMINATED = 3
} ProcessState;

typedef struct {
    int          pid;
    char         name[16];
    int          burst_time;
    int          remaining;
    int          priority;
    int          wait_time;
    int          turnaround;
    ProcessState state;
} Process;

void scheduler_init();
int  process_create(const char* name, int burst_time, int priority);
void process_terminate(int pid);
void scheduler_run_fcfs();
void scheduler_run_rr();
void scheduler_list_processes();
int  scheduler_get_count();

#endif
