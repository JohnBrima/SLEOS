#ifndef FILESYSTEM_H
#define FILESYSTEM_H

void fs_init();
int  fs_create(const char* name);
int  fs_write(const char* name, const char* content);
int  fs_read(const char* name, char* out, int max_len);
int  fs_delete(const char* name);
void fs_list();

#endif
