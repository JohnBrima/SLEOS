#include "screen.h"

volatile uint16_t* vga_buffer = (uint16_t*)0xB8000;

static int cursor_row = 0;
static int cursor_col = 0;
static uint8_t current_color = 0x07;

static void outb(uint16_t port, uint8_t val) {
    __asm__ volatile ("outb %0, %1" : : "a"(val), "Nd"(port));
}

static void update_cursor() {
    uint16_t pos = cursor_row * VGA_WIDTH + cursor_col;
    outb(0x3D4, 0x0F);
    outb(0x3D5, (uint8_t)(pos & 0xFF));
    outb(0x3D4, 0x0E);
    outb(0x3D5, (uint8_t)((pos >> 8) & 0xFF));
}

static uint16_t make_vga_entry(char c, uint8_t color) {
    return (uint16_t)c | ((uint16_t)color << 8);
}

void scroll() {
    for (int r = 1; r < VGA_HEIGHT; r++)
        for (int c = 0; c < VGA_WIDTH; c++)
            vga_buffer[(r-1)*VGA_WIDTH+c] = vga_buffer[r*VGA_WIDTH+c];
    for (int c = 0; c < VGA_WIDTH; c++)
        vga_buffer[(VGA_HEIGHT-1)*VGA_WIDTH+c] = make_vga_entry(' ', current_color);
    cursor_row = VGA_HEIGHT - 1;
}

void screen_putchar(char c) {
    if (c == '\n') {
        cursor_col = 0;
        cursor_row++;
    } else if (c == '\r') {
        cursor_col = 0;
    } else if (c == '\b') {
        if (cursor_col > 0) cursor_col--;
        vga_buffer[cursor_row*VGA_WIDTH+cursor_col] = make_vga_entry(' ', current_color);
    } else {
        vga_buffer[cursor_row*VGA_WIDTH+cursor_col] = make_vga_entry(c, current_color);
        if (++cursor_col >= VGA_WIDTH) { cursor_col = 0; cursor_row++; }
    }
    if (cursor_row >= VGA_HEIGHT) scroll();
    update_cursor();
}

void screen_print(const char* str) {
    while (*str) screen_putchar(*str++);
}

void screen_print_int(int num) {
    if (num == 0) { screen_putchar('0'); return; }
    if (num < 0) {
        screen_putchar('-');
        if (num == -2147483648) { screen_print("2147483648"); return; }
        num = -num;
    }
    char buf[12];
    int i = 0;
    while (num > 0) { buf[i++] = '0' + (num % 10); num /= 10; }
    while (--i >= 0) screen_putchar(buf[i]);
}

void screen_print_hex(uint32_t num) {
    screen_print("0x");
    const char hex[] = "0123456789ABCDEF";
    for (int i = 28; i >= 0; i -= 4)
        screen_putchar(hex[(num >> i) & 0xF]);
}

void screen_set_color(uint8_t fg, uint8_t bg) {
    current_color = (bg << 4) | (fg & 0x0F);
}

void clear_screen() {
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++)
        vga_buffer[i] = make_vga_entry(' ', current_color);
    cursor_row = cursor_col = 0;
    update_cursor();
}

int screen_get_row() { return cursor_row; }
int screen_get_col() { return cursor_col; }
