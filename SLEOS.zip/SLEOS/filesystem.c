#include "filesystem.h"
#include "screen.h"

#define MAX_FILES     8
#define MAX_FILE_SIZE 256

typedef struct {
    char name[32];
    char data[MAX_FILE_SIZE];
    int  size;
    int  active;
} File;

static File fs_table[MAX_FILES];
static int  file_count = 0;

static void str_copy(char* dst, const char* src, int max) {
    int i = 0;
    while (src[i] && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = '\0';
}

static int str_eq(const char* a, const char* b) {
    while (*a && *b) { if (*a != *b) return 0; a++; b++; }
    return *a == *b;
}

static int fs_find(const char* name) {
    for (int i = 0; i < MAX_FILES; i++)
        if (fs_table[i].active && str_eq(fs_table[i].name, name)) return i;
    return -1;
}

void fs_init() {
    for (int i = 0; i < MAX_FILES; i++) { fs_table[i].active = 0; fs_table[i].size = 0; }
    file_count = 0;
}

int fs_create(const char* name) {
    if (fs_find(name) != -1 || file_count >= MAX_FILES) return 0;
    for (int i = 0; i < MAX_FILES; i++) {
        if (!fs_table[i].active) {
            str_copy(fs_table[i].name, name, 32);
            fs_table[i].data[0] = '\0';
            fs_table[i].size    = 0;
            fs_table[i].active  = 1;
            file_count++;
            return 1;
        }
    }
    return 0;
}

int fs_write(const char* name, const char* content) {
    int idx = fs_find(name);
    if (idx == -1) { if (!fs_create(name)) return 0; idx = fs_find(name); }
    int i = 0;
    while (content[i] && i < MAX_FILE_SIZE - 1) { fs_table[idx].data[i] = content[i]; i++; }
    fs_table[idx].data[i] = '\0';
    fs_table[idx].size = i;
    return 1;
}

int fs_read(const char* name, char* out, int max_len) {
    int idx = fs_find(name);
    if (idx == -1) return 0;
    int i = 0;
    while (fs_table[idx].data[i] && i < max_len - 1) { out[i] = fs_table[idx].data[i]; i++; }
    out[i] = '\0';
    return i;
}

int fs_delete(const char* name) {
    int idx = fs_find(name);
    if (idx == -1) return 0;
    fs_table[idx].active = 0;
    fs_table[idx].size   = 0;
    file_count--;
    return 1;
}

void fs_list() {
    screen_print("[FS] Files:\n");
    int found = 0;
    for (int i = 0; i < MAX_FILES; i++) {
        if (fs_table[i].active) {
            screen_print("  "); screen_print(fs_table[i].name);
            screen_print(" ("); screen_print_int(fs_table[i].size); screen_print(" bytes)\n");
            found++;
        }
    }
    if (!found) screen_print("  (empty)\n");
}
