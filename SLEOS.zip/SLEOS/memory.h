#ifndef MEMORY_H
#define MEMORY_H

#include "kernel.h"

typedef struct {
    int  alloc_id;
    char label[16];
    int  frames_start;
    int  num_frames;
    int  active;
} Allocation;

void memory_init();
int  memory_alloc(const char* label, int size_kb);
int  memory_free(int alloc_id);
void memory_show_map();
int  memory_get_free_kb();
int  memory_get_total_kb();

#endif
