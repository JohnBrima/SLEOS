#include "keyboard.h"
#include "screen.h"

static uint8_t inb(uint16_t port) {
    uint8_t result;
    __asm__ volatile ("inb %1, %0" : "=a"(result) : "Nd"(port));
    return result;
}

static const char scancode_map[] = {
    0,   0,  '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', '\b',
    '\t','q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', '\n',
    0,   'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0,  '\\','z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,
    '*', 0,  ' '
};

static const char scancode_map_shift[] = {
    0,   0,  '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', '\b',
    '\t','Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', '\n',
    0,   'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~',
    0,  '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,
    '*', 0,  ' '
};

static int shift_pressed = 0;

char keyboard_getchar() {
    uint8_t scancode, status;
    do { status = inb(0x64); } while (!(status & 0x01));
    scancode = inb(0x60);
    if (scancode == 0x2A || scancode == 0x36) { shift_pressed = 1; return 0; }
    if (scancode == 0xAA || scancode == 0xB6) { shift_pressed = 0; return 0; }
    if (scancode & 0x80) return 0;
    if (scancode < sizeof(scancode_map))
        return shift_pressed ? scancode_map_shift[scancode] : scancode_map[scancode];
    return 0;
}

void keyboard_readline(char* buf, int len) {
    int i = 0;
    char c;
    while (i < len - 1) {
        c = keyboard_getchar();
        if (!c) continue;
        if (c == '\n') {
            buf[i] = '\0';
            screen_putchar('\n');
            return;
        } else if (c == '\b') {
            if (i > 0) { i--; screen_putchar('\b'); }
        } else {
            buf[i++] = c;
            screen_putchar(c);
        }
    }
    buf[i] = '\0';
}
