#ifndef KEYBOARD_H
#define KEYBOARD_H

#include "kernel.h"

char keyboard_getchar();
void keyboard_readline(char* buf, int len);

#endif
