#ifndef SCREEN_H
#define SCREEN_H

#include "kernel.h"

#define VGA_WIDTH  80
#define VGA_HEIGHT 25

void clear_screen();
void scroll();
void screen_putchar(char c);
void screen_print(const char* str);
void screen_print_int(int num);
void screen_print_hex(uint32_t num);
void screen_set_color(uint8_t fg, uint8_t bg);
int  screen_get_row();
int  screen_get_col();

#endif
