#include "scheduler.h"
#include "screen.h"

#define TIME_QUANTUM 3

static Process process_table[MAX_PROCESSES];
static int process_count = 0;
static int next_pid = 1;

void scheduler_init() {
    process_count = 0;
    next_pid = 1;
    for (int i = 0; i < MAX_PROCESSES; i++)
        process_table[i].state = PROC_EMPTY;
}

int process_create(const char* name, int burst_time, int priority) {
    if (process_count >= MAX_PROCESSES || burst_time <= 0) return -1;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i].state == PROC_EMPTY) {
            process_table[i].pid        = next_pid++;
            process_table[i].burst_time = burst_time;
            process_table[i].remaining  = burst_time;
            process_table[i].priority   = priority;
            process_table[i].wait_time  = 0;
            process_table[i].turnaround = 0;
            process_table[i].state      = PROC_READY;
            int j = 0;
            while (name[j] && j < 15) { process_table[i].name[j] = name[j]; j++; }
            process_table[i].name[j] = '\0';
            process_count++;
            return process_table[i].pid;
        }
    }
    return -1;
}

void process_terminate(int pid) {
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i].pid == pid && process_table[i].state != PROC_EMPTY) {
            process_table[i].state = PROC_TERMINATED;
            process_count--;
            return;
        }
    }
}

void scheduler_run_fcfs() {
    if (!process_count) { screen_print("[SCHED] No processes.\n"); return; }
    int time = 0;
    screen_print("[SCHED] FCFS Simulation:\n");
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i].state == PROC_READY) {
            process_table[i].wait_time  = time;
            time                       += process_table[i].burst_time;
            process_table[i].turnaround = time;
            process_table[i].state      = PROC_TERMINATED;
            screen_print("  PID "); screen_print_int(process_table[i].pid);
            screen_print(" ["); screen_print(process_table[i].name); screen_print("]");
            screen_print(" wait="); screen_print_int(process_table[i].wait_time);
            screen_print(" turnaround="); screen_print_int(process_table[i].turnaround);
            screen_print("\n");
        }
    }
}

void scheduler_run_rr() {
    if (!process_count) { screen_print("[SCHED] No processes.\n"); return; }
    for (int i = 0; i < MAX_PROCESSES; i++)
        if (process_table[i].state != PROC_EMPTY)
            process_table[i].remaining = process_table[i].burst_time;

    int time = 0, finished = 0;
    screen_print("[SCHED] Round Robin (quantum=");
    screen_print_int(TIME_QUANTUM);
    screen_print("):\n");

    while (finished < process_count) {
        int progress = 0;
        for (int i = 0; i < MAX_PROCESSES; i++) {
            if (process_table[i].state == PROC_READY && process_table[i].remaining > 0) {
                int run = process_table[i].remaining < TIME_QUANTUM
                        ? process_table[i].remaining : TIME_QUANTUM;
                process_table[i].remaining -= run;
                time += run;
                progress = 1;
                if (!process_table[i].remaining) {
                    process_table[i].turnaround = time;
                    process_table[i].state = PROC_TERMINATED;
                    finished++;
                    screen_print("  PID "); screen_print_int(process_table[i].pid);
                    screen_print(" ["); screen_print(process_table[i].name); screen_print("]");
                    screen_print(" done at t="); screen_print_int(time); screen_print("\n");
                }
            }
        }
        if (!progress) break;
    }
}

void scheduler_list_processes() {
    screen_print("[SCHED] Process list:\n");
    int found = 0;
    for (int i = 0; i < MAX_PROCESSES; i++) {
        if (process_table[i].state != PROC_EMPTY) {
            screen_print("  PID "); screen_print_int(process_table[i].pid);
            screen_print(" ["); screen_print(process_table[i].name); screen_print("] burst=");
            screen_print_int(process_table[i].burst_time); screen_print("\n");
            found++;
        }
    }
    if (!found) screen_print("  (none)\n");
}

int scheduler_get_count() { return process_count; }
